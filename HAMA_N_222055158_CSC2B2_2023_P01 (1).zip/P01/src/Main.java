import acsse.csc2b.SMTP;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * @author nyash
 *
 */
public class Main extends Application{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);

	}
	
	private SMTP simpleMail = null;

	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		//setting up the SMTP constructor
		simpleMail = new SMTP("localHost",25,"kig@csc2b.uj.ac.za","macho@csc2b.uj.ac.za","Test","a");
        //creating a new scene 
        Scene newScene = new Scene(simpleMail);
        arg0.setTitle("SMTP");
		arg0.setScene(newScene);
		arg0.setWidth(900);
		arg0.setHeight(400);
		//showing the stage
		arg0.show();
		
	}

}
