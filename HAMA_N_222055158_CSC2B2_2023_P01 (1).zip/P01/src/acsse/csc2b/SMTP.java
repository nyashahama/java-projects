/**
 * 
 */
package acsse.csc2b;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;


/**
 * @author nyash
 *
 */
public class SMTP extends GridPane {
	
	private String host;
	public String getHost()
	{
		//this.host=host;
		return host;
	}
    private int port;
    public int getPort()
    {
    	return port;
    }
    private String sender;
    public String getSenderEmail()
    {
    	return sender;
    }
    private String receiver; 
    public String getReceiverEmail()
    {
    	return receiver;
    }
    private String content;
    public String getContent()
    {
    	return content;
    }
    private String subject;
    public String getSub()
    {
    	return subject;
    }
	
	private Socket smtpSocket =null;
	private BufferedReader in = null;
	private PrintWriter out = null;
	
	private TextArea contentArea;
	
	private TextField hostName;
	private TextField senderName;
	private TextField portName;
	private TextField receiverName;
	
	
	public SMTP(String host, int port, String sender, String receiver, String subject, String content)
	{
		this.host = host;
        this.port = port;
        this.sender = sender;
        this.receiver = receiver;
        this.subject = subject;
        this.content = content;
	  setUpGUI();
	}
	
	public void setUpGUI()
	{

		hostName = new TextField(host);
		portName = new TextField(Integer.toString(port));
		senderName = new TextField(sender); //setting text for senderName
		receiverName = new TextField(receiver); //setting text for receiverName
		
		Label hostlabel = new Label("Host");
		add(hostlabel, 0, 0);
		add(hostName, 1, 0);
			
		Label portlabel = new Label("Port");
		add(portlabel, 0, 1);
		add(portName, 1 ,1);
		
		Label senderlabel = new Label("Sender");
		add(senderlabel, 0, 2);
		add(senderName, 1, 2);
		
		Label recipientlabel = new Label("Recipient");
		add(recipientlabel, 0, 3);
		add(receiverName, 1, 3);
				
		contentArea = new TextArea(content);
		contentArea.setEditable(false);
		add(contentArea,0,4,1,2);
			
		//instatiating a send button
		Button sendmsg = new Button("Send");
		sendmsg.setOnAction(e -> 
								sendEmail() //using the lambda expression
								);
		add(sendmsg,1,5);
		
		setPadding(new Insets(10));
		setVgap(5); //for vertical gap
		setHgap(10); //for horizontal gap

	}
	//a helper function to establish connection 
	private void makeConnection() throws IOException {
        smtpSocket = new Socket(host, port);
        System.out.println("Connected");
        out = new PrintWriter(smtpSocket.getOutputStream(), true);
        in = new BufferedReader(new InputStreamReader(smtpSocket.getInputStream()));
        //response from server after established connection
        receivedMessg();
    }
    
	//a helper function to receive info from the server
    private String receivedMessg() throws IOException {
        String response = in.readLine();
        System.out.println("Server: " + response);
        return response;
    }

    //a helper function to give instructions
    private void sendCommand(String cmd) {
        out.println(cmd);
        out.flush();
        System.out.println("Client: " + cmd);
    }

    //has all the SMTP commands to give and receive response from server
    public void sendEmail() {
        try {
        	//using a helper function to establish connection
        	makeConnection();
            
        	//using the send command helper function for the HELO command
            sendCommand("HELO " + host);
            //receiving the instruction fro the server
            receivedMessg();

            //using the send command helper function for the MAIL FROM command
            sendCommand("MAIL FROM:<" + sender + ">");
            //receiving instruction
            receivedMessg();

            //using the send command helper function for the RCPT TO command
            sendCommand("RCPT TO:<" + receiver + ">");
            //feedback
            receivedMessg();

            //using the send command helper function for the HELO command
            sendCommand("DATA");
            //info
            receivedMessg();

            
            sendCommand("Subject: " + subject);
            sendCommand("From: " + sender);
            sendCommand("To: " + receiver);           
            sendCommand(content);
            sendCommand(".");
            receivedMessg();

            //quiting command
            sendCommand("QUIT");
            receivedMessg();
            
        } catch (UnknownHostException ex) {
            System.err.println("Could not find the host");
        } catch (IOException ex) {
            System.err.println("Failed to find");
        } finally {
            try {
                if (smtpSocket != null) {
                    smtpSocket.close();
                }
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                System.err.println("Failed to close connection " );
            }
        }
    }

    

}
