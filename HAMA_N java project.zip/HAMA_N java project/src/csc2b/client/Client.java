/**
 * 
 */
package csc2b.client;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * @author General
 *
 */
public class Client extends Application{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//launch the JavaFX Application
    	launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		//create the ClientPane, set up the Scene and Stage
		ZEDEMClientPane root  = new ZEDEMClientPane();
		Scene scene = new Scene(root,800,600);
		primaryStage.setTitle("BUKA client");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}
