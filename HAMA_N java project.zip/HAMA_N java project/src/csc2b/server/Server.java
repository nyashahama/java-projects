/**
 * 
 */
package csc2b.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author General
 *
 */
public class Server {

	/**
	 * @param args
	 */
	
	private ServerSocket server;
	private boolean isReady;
	
	public Server(int port)
	{
		
		try {
			server = new ServerSocket(port);
			System.out.println("Server created on port: " + port);
			isReady = true;
			
			while(isReady)
			{
				System.out.println("Waiting to accept clients");
				Socket clientConn = server.accept();
				Thread clientThread = new Thread(new ZEDEMHandler(clientConn));
				clientThread.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Setup server socket and pass on handling of request
          @SuppressWarnings("unused")
		Server server = new Server(2021);
	}

}
