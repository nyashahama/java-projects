package acsse.csc2b;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.StringTokenizer;

public class Connect {
    //declaration of variables
	private Socket socket = null;
	private InetAddress iPAdress = null;
	
	//a non args constructor that initializes the InetAddress
	public Connect()
	{
		//error handling using a try catch block
		try {
			iPAdress = InetAddress.getLocalHost();
			//StreamTokenizer breaks up an input String into tokens
			StringTokenizer tokens = new StringTokenizer(iPAdress.toString(), "/");
			System.out.println("The computer IP Address is :" + tokens.nextToken());
		} catch (UnknownHostException ex) {
			
			System.out.println("Could not find the host");
		}
	}
	
	public void Display()
	{
		//looping from 1 to 65535 with an incrementation of 3+
		for(int i=1;i<65535;i=i+3)
		{
			//error handling
			try {
				socket = new Socket(iPAdress,i);
				if(socket.isConnected())
				{
					System.out.println("Program connected to localhost port :" + socket.getPort());
					System.out.println("Local port of the connection :" + socket.getLocalPort());
					System.out.println("Remote port of the connection :" + socket.getPort());
				}
				//handling the UnknownHostException 
			}catch(UnknownHostException ex)
			{
				System.err.println("Could not connect to localhost port :" +i);
			}
			//handlinhg the IOException
			catch (IOException e) {
				
				System.err.println("Could not connect to localhost port :" +i);
			}
			finally
			{
				if(socket!=null)
				{
					try
					{
						//closing the connection and handling exceptions
						socket.close();
					}catch(IOException ex)
					{
						System.err.println("Failed to close the Socket");
					}
				}
			}
			
		}
	}
	
     //it's good practice to include accessors and mutators
	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public InetAddress getiPAdress() {
		return iPAdress;
	}

	public void setiPAdress(InetAddress iPAdress) {
		this.iPAdress = iPAdress;
	}
}
