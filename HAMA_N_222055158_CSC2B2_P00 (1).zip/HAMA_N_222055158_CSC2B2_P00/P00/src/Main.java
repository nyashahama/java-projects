import acsse.csc2b.Connect;

/**
 * 
 */

/**
 * @author General
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//creating a Connect instance, using the non-args constructor
		Connect port = new Connect();
		//polymorphism calling the Display function from the Connect class using a connect instance
		port.Display();
	}

}
