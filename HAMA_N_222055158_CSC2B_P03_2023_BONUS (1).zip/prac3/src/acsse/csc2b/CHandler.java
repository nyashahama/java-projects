/**
 * 
 */
package acsse.csc2b;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;

/**
 * @author General
 *
 */
public class CHandler implements Runnable {
	
	//variable declaration
	private Socket socket = null;
	private BufferedReader br = null;
	private DataOutputStream dos = null;
	private BufferedInputStream bis = null;
	
	//one argument constructor
	public CHandler(Socket socketConnection) {
		// TODO Auto-generated constructor stub
		this.socket = socketConnection;
	}

	//overridable function for muilti-threading
	@Override
	public void run() {
		// TODO Auto-generated method stub
		//handling exceptions
		try
		{
			//initializing declared variables
			br = new BufferedReader(new InputStreamReader
					                (socket.getInputStream()));
			dos = new DataOutputStream(new BufferedOutputStream(
					                   socket.getOutputStream()));
			
			//requesting a message
			String requestMessage = br.readLine();
			System.out.println(requestMessage);
			//breaking the requesteMessage into tokens
			StringTokenizer tokens = new StringTokenizer(requestMessage);
			String requestMessageType = tokens.nextToken();
			
			//handling the 500 error
			if(requestMessageType.length()<2)
			{
				sendErr(dos,500,"Invalid Request");
			}
			//creating a file path
			String fileName =  tokens.nextToken();
			String path = "data/"+fileName;
			//intializing the file using the declared path
			File file = new File(path);
			
			//checking if the file exists
			if(file.exists())
			{
				
				if(requestMessageType.equals("GET"));
				{
					//using the getContentType function
					String contentType = getContentType(fileName);
					//messages
					dos.writeBytes("HTTP/1.1 200 OK \r\n");
	                dos.writeBytes("Connection: close \r\n");
	                dos.writeBytes("Content-Type: " + contentType + "\r\n"); //checks the contentType and returns
	                dos.writeBytes("Content-Length:" + file.length() + "\r\n");
	                dos.writeBytes("\r\n");
	                
	                bis = new BufferedInputStream(new FileInputStream(file));
	                byte[] buffer = new byte[1024];
	                int n = 0;
	                
	                while((n=bis.read(buffer))>0)
	                {
	                	dos.write(buffer,0,n);
	                }
	                bis.close();
	                dos.writeBytes("\r\n");
	                dos.flush();
				}
			}else
			{
				sendErr(dos, 404, "File Not Found");
			}
			
			
		}catch(IOException ex)
		{
			System.err.println("Could not connect");
		}
		finally
		{
			try {
				br.close();
				dos.close();
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				System.err.println("Failed To Close"+ex);
			}
			
		}
		
	}
     
	// a helper function to check content type
	private String getContentType(String fileName) {
		// TODO Auto-generated method stub
		if(fileName.endsWith(".html"))
		{
			return "text/html";
			
		}else if(fileName.endsWith(".jpg"))
		{
			return "image/jpg";
		}else if(fileName.endsWith(".png"))
		{
			return "image/png";
		}else
		{
			return "video/m4v";
		}
	}
    
	//a function to handle errors
	private void sendErr(DataOutputStream dos2, int i, String message) {
		// TODO Auto-generated method stub
		
		String content = "<html><head><title>Error</title></head><body>" 
                          + message + "</body></html>"; //html tags


		String errMsg = " ";
		switch(i)
		{
		case 200:
			errMsg ="OK, No issues";
			break;
		case 404:
			errMsg ="404 Requested Page Not found";
			break;
			
		case 500:
			errMsg="500 An Error Occured";
			break;
		}
		//handling exceptions
		try
		{
			dos.writeBytes("HTTP/1.1"+ i +"\r\n");
			dos.writeBytes("Connection: close\r\n");
			dos.writeBytes("Content-length: "+content.getBytes().length +"\r\n");
			dos.writeBytes("\r\n");
			dos.writeBytes(content);
			dos.writeBytes("\r\n");
			dos.flush();
		}catch(IOException ex)
		{
			System.err.println("FAILED"+ex);
		}
		
	}
	
	

}
