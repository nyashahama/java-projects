/**
 * 
 */
package acsse.csc2b;

import java.io.IOException;
import java.net.ServerSocket;

/**
 * @author General
 *
 */
public class HttpServer {
	
	private ServerSocket serverSocket = null;
	boolean flag = false;
	
	//argumented constructor
	public HttpServer(int portNum) {
		// TODO Auto-generated constructor stub
		//handling exception
		try {
			serverSocket = new ServerSocket(portNum);
			flag = true;
		} catch (IOException ex) {
			// TODO Auto-generated catch block
			System.err.println("Failed to find the port"+ex);
		}
		
	}
	
	//a helper method to initiate the server using multi-threading
	public void initiateServer()
	{
		while(flag)
		{
			//handling exception
			try {
				Thread t = new Thread(new CHandler(serverSocket.accept()));
				t.start();
				System.out.println("Server is waiting on port"+serverSocket.getLocalPort());
			} catch (IOException ex) {
				// TODO Auto-generated catch block
				System.err.println("Failed to connect to the server"+ex);
			}
		}
	}

}
