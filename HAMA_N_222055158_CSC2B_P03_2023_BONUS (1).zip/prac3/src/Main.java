import acsse.csc2b.HttpServer;

/**
 * 
 */

/**
 * @author General
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        HttpServer newServer = new HttpServer(4326);
        newServer.initiateServer();		
	}

}
