/**
 * 
 */
package acsse.csc2b.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * @author nyash
 *
 */
public class BUKAClientPane extends GridPane {
    private Button btnConnect;
    private Button btnList;
    private Button btnRequestPDF;
    private Button btnLogout;
    private TextArea responseArea;
    private TextArea listArea;
    private TextField txtIDToRetrieve;

    private Socket socket;
    private OutputStream os;
    private InputStream is;
    private PrintWriter pw;
    private BufferedReader br;
    private DataOutputStream dos;
    private DataInputStream dis;
    private String[] listData;

    private boolean authenticated = true;

    public BUKAClientPane(Stage stage) {
        setUPGUI();

        btnConnect.setOnAction((e) -> {
            try {
                socket = new Socket("localhost", 2018);
                os = socket.getOutputStream();
                is = socket.getInputStream();
                br = new BufferedReader(new InputStreamReader(is));
                pw = new PrintWriter(os, true);
                dis = new DataInputStream(is);
                dos = new DataOutputStream(os);

            } catch (IOException ex) {
                System.err.println("Connection error: " + ex.getMessage());
            }
        });

        btnList.setOnAction((e) -> {
            if (authenticated) {
                sendCommand("LIST");
                String response = ReadResponse(br);
                System.out.println(response);

                listData = response.split("#");

                for (String s : listData) {
                    listArea.appendText(s + "\n");
                }
            } else {
                responseArea.appendText("Please authenticate first.\n");
            }
        });

        btnRequestPDF.setOnAction((e) -> {
            if (authenticated) {
                String idToRetrieveText = txtIDToRetrieve.getText();
                if (!idToRetrieveText.isEmpty()) {
                    sendCommand("PDFRET", idToRetrieveText);
                } else {
                    responseArea.appendText("Invalid PDF ID.\n");
                }
            } else {
                responseArea.appendText("Please authenticate first.\n");
            }
        });

        btnLogout.setOnAction((e) -> {
            if (authenticated) {
                sendCommand("LOGOUT");
                authenticated = false;
            } else {
                responseArea.appendText("You are not logged in.\n");
            }
        });
    }

    private void setUPGUI() {
        setVgap(10);
        setHgap(10);
        setAlignment(Pos.CENTER);

        Label lblInstructions = new Label("1. Connect to Server");
        Label lblIMGLST = new Label("2. Get Image List");
        Label lblGETIMG = new Label("3. Download Image by ID");
        Label lblPOSTIMG = new Label("4. Upload Image to Server");

        btnConnect = new Button("Connect");
        add(lblInstructions, 0, 0);
        add(btnConnect, 1, 0);

        btnList = new Button("Get Image List");
        add(lblIMGLST, 0, 1);
        add(btnList, 1, 1);

        btnRequestPDF = new Button("Download Image");
        add(lblGETIMG, 0, 2);
        add(btnRequestPDF, 1, 2);

        btnLogout = new Button("Logout");
        add(lblPOSTIMG, 0, 3);
        add(btnLogout, 1, 3);

        listArea = new TextArea();
        listArea.setPrefHeight(100);
        add(listArea, 0, 5, 2, 1);

        txtIDToRetrieve = new TextField();
        txtIDToRetrieve.setPromptText("Enter Image ID");
        add(txtIDToRetrieve, 0, 6, 2, 1);

        responseArea = new TextArea();
        responseArea.setPrefHeight(150);
        add(responseArea, 0, 7, 2, 1);
    }

    private void sendCommand(String command, String... args) {
        StringBuilder fullCommand = new StringBuilder(command);
        for (String arg : args) {
            fullCommand.append(" ").append(arg);
        }
        pw.println(fullCommand.toString());
        pw.flush();
    }

    private String ReadResponse(BufferedReader br) {
        String response = "";
        try {
            response = br.readLine();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return response;
    }
}
