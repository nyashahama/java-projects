/**
 * 
 */
package acsse.csc2b.server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * @author nyash
 *
 */
public class BUKAHandler implements Runnable {
    private Socket connection;
    private OutputStream os;
    private InputStream is;
    private PrintWriter pw;
    private BufferedReader br;
    private DataOutputStream dos;
    private DataInputStream dis;

    private boolean authenticated = false;

    public BUKAHandler(Socket s) {
        this.connection = s;

        try {
            os = connection.getOutputStream();
            is = connection.getInputStream();
            pw = new PrintWriter(os, true);
            br = new BufferedReader(new InputStreamReader(is));
            dos = new DataOutputStream(os);
            dis = new DataInputStream(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        System.out.println("Handling client requests...");
        try {
            while (true) {
                String message = br.readLine();
                System.out.println("Message: " + message);
                StringTokenizer st = new StringTokenizer(message);
                String command = st.nextToken().toUpperCase();

                switch (command) {
                    case "AUTH":
                        if (st.hasMoreTokens()) {
                            String name = st.nextToken();
                            if (st.hasMoreTokens()) {
                                String password = st.nextToken();
                                if (authenticate(name, password)) {
                                    pw.println("200 Authentication successful");
                                    authenticated = true;
                                } else {
                                    pw.println("500 Authentication failed");
                                }
                            } else {
                                pw.println("500 Authentication failed: Password not provided");
                            }
                        } else {
                            pw.println("500 Authentication failed: Username not provided");
                        }
                        break;

                    case "LIST":
                        if (authenticated) {
                            sendImageList();
                        } else {
                            pw.println("500 Please authenticate first");
                        }
                        break;

                    case "PDFRET":
                        if (authenticated && st.hasMoreTokens()) {
                            String id = st.nextToken();
                            sendPDF(id);
                        } else {
                            pw.println("500 Invalid request");
                        }
                        break;

                    case "LOGOUT":
                        authenticated = false;
                        pw.println("200 Logout successful");
                        break;

                    default:
                        pw.println("500 Invalid command");
                        break;
                }
                pw.flush();
            }
        } catch (IOException ex) {
            System.err.println("Failed to process client request: " + ex.getMessage());
        }
    }

    private boolean authenticate(String name, String password) {
        // Implement your authentication logic here.
        // You can compare the provided name and password with a database or a hardcoded list.
        // For testing, you can use a simple check like the following:
        return name.equals("Drizzy") && password.equals("p455w0rd");
    }

    private void sendImageList() {
        try {
            StringBuilder imageList = new StringBuilder();
            File fileList = new File("data/server/ImgList.txt");
            Scanner sc = new Scanner(fileList);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                StringTokenizer tokenizer = new StringTokenizer(line);
                String id = tokenizer.nextToken();
                String name = tokenizer.nextToken();
                imageList.append(id).append(" ").append(name).append("#");
            }
            sc.close();

            pw.println("200 " + imageList.toString());
        } catch (IOException ex) {
            System.err.println("Error while sending image list: " + ex.getMessage());
            pw.println("500 Error fetching image list");
        }
    }

    private void sendPDF(String id) {
        try {
            File fileList = new File("data/server/ImgList.txt");
            Scanner sc = new Scanner(fileList);
            String fileName = null;

            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                StringTokenizer tokenizer = new StringTokenizer(line);
                String fileID = tokenizer.nextToken();
                String name = tokenizer.nextToken();

                if (fileID.equals(id)) {
                    fileName = name;
                    break; // No need to continue the loop once the file name is found
                }
            }
            sc.close();

            if (fileName != null) {
                File fileToReturn = new File("data/server/" + fileName);
                if (fileToReturn.exists()) {
                    long fileSize = fileToReturn.length();
                    pw.println("200 " + fileSize);

                    FileInputStream fis = new FileInputStream(fileToReturn);
                    byte[] buffer = new byte[2048];
                    int n;
                    while ((n = fis.read(buffer)) > 0) {
                        dos.write(buffer, 0, n);
                        dos.flush();
                    }
                    fis.close();
                } else {
                    pw.println("500 Requested file not found");
                }
            } else {
                pw.println("500 Invalid PDF ID");
            }
        } catch (IOException ex) {
            System.err.println("Error while handling PDF request: " + ex.getMessage());
            pw.println("500 Error handling PDF request");
        }
    }
}