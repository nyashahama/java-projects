/**
 * 
 */
package acsse.csc2b.server;

import java.io.IOException;
import java.net.ServerSocket;

/**
 * @author nyash
 *
 */
public class Server {

	/**
	 * @param args
	 */
	private ServerSocket ss;
	private boolean isRunning;
	
	public Server(int port) {
		// TODO Auto-generated constructor stub
		try {
			ss= new ServerSocket(port);
			isRunning = true;
			runServer();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	  

	private void runServer() {
		// TODO Auto-generated method stub
		System.out.println("Starting server");
		while(isRunning)
		{
			try {
				//Socket incoming = ss.accept();
				System.out.println("Connected");
				BUKAHandler serverhandler = new BUKAHandler(ss.accept());
				Thread thread = new Thread(serverhandler);
				thread.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Server s = new Server(2021);
        s.runServer();
	}


}
