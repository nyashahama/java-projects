For these batch files to work ensure your package structure is as folows:

Server:
acsse.csc2b.server
	ImgServer.java (main server class name)

Client:
acsse.csc2b.client
	ImgClient.java (main client class name)

