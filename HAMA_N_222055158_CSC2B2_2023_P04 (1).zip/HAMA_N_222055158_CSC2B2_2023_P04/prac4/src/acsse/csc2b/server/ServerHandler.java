/**
 * 
 */
package acsse.csc2b.server;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * @author General
 *
 */
public class ServerHandler implements Runnable {
	
	private Socket connection;
	private OutputStream os;
	private InputStream is;
	private PrintWriter pw;
	private BufferedReader br;
	private DataOutputStream dos;
	private DataInputStream dis;
	
	private boolean processing;
	
	

	public ServerHandler(Socket s) {
		// TODO Auto-generated constructor stub
		this.connection = s;
		
		try {
			os = connection.getOutputStream();
			is = connection.getInputStream();
			pw = new PrintWriter(os);
			br = new BufferedReader(new InputStreamReader(is));
			dos = new DataOutputStream(os);
			dis = new DataInputStream(is);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Handling client requests...");
		processing = true;
		
		try
		{
			while(processing)
			{
				String message = br.readLine();
				System.out.println("Message: "+message);
				StringTokenizer st = new StringTokenizer(message);
				String command = st.nextToken().toUpperCase();
				switch(command)
				{
				case "PULL":
					pw.println(loadImageLists());
					pw.flush();
					break;
					
				case "DOWNLOAD":
				    String fileID = st.nextToken();
				    System.out.println("ID requested: " + fileID);
				    String fileName = "";

				    File fileList = new File("data/server/ImgList.txt");
				    Scanner sc = new Scanner(fileList);
				    while (sc.hasNext()) {
				        String line = sc.nextLine();
				        StringTokenizer tokenizer = new StringTokenizer(line);
				        String id = tokenizer.nextToken();
				        String fName = tokenizer.nextToken();
				        if (id.equals(fileID)) {
				            fileName = fName;
				            break; // No need to continue the loop once the file name is found
				        }
				    }
				    sc.close();

				    File fileToReturn = new File("data/server/" + fileName);
				    if (fileToReturn.exists()) {
				        long fileSize = fileToReturn.length();
				        pw.println(fileSize);
				        pw.flush();

				        FileInputStream fis = new FileInputStream(fileToReturn);
				        byte[] buffer = new byte[2048];
				        int n;
				        while ((n = fis.read(buffer)) > 0) {
				            dos.write(buffer, 0, n);
				            dos.flush();
				        }
				        fis.close();
				        System.out.println("File sent to client: " + fileName);
				    } else {
				        System.out.println("Requested file not found: " + fileName);
				    }
				    break; // End the case "DOWNLOAD" block

				case "UPLOAD":
					String fileRecID = st.nextToken();
					String fileRecName = st.nextToken();
					
					int size = Integer.parseInt(st.nextToken());
					PrintWriter p = new PrintWriter(new BufferedWriter(new FileWriter("data/server/ImgList.txt",true)));
					p.println("\n"+fileRecID +" "+ fileRecName);
					p.close();
					System.out.println("File appended to list");
					File fileToReceive = new File("data/server/"+fileRecName);
					FileOutputStream fos = null;
					System.out.println("still getting bytes...");
					
					try {
						fos = new FileOutputStream(fileToReceive);
						byte[] buffer = new byte[1024];
						int n = 0;
						int totalBytes = 0;
						while(totalBytes!=size)
						{
							n = dis.read(buffer, 0, buffer.length);
							fos.write(buffer,0,n);
							fos.flush();
							totalBytes += n;
						}
						pw.println("HAPPY");
						pw.flush();
						System.out.println("DONE File uploaded to server");
						
					}catch (IOException ex)
					{
						pw.println("SAD");
						pw.flush();
						System.err.println("not this one");
					}
					break;
				}
			}
			
		}catch(IOException ex)
		{
			System.err.println("Failed");
		}
		
	}
	

	private String loadImageLists() {
		// TODO Auto-generated method stub
		String retype ="";
		try {
			Scanner scanner = new Scanner(new File("data/server/ImgList.txt"));
			while(scanner.hasNextLine())
			{
				String img = scanner.nextLine();
				retype += img +"#";
			}
			System.out.println("Image list loaded");
			scanner.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return retype;
	}

}
