/**
 * 
 */
package acsse.csc2b.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.StringTokenizer;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * @author General
 *
 */
public class ClientPane extends GridPane{
	
	private Button btnConnect;
	private Button btnPULL;
	private Button btnDOWNLOAD;
	private Button btnUPLOAD;
	private TextArea responseArea;
	private TextArea listArea;
	private TextField txtIDToRetrieve;
	
	
	private Socket socket;
	private OutputStream os;
	private InputStream is;
	private PrintWriter pw;
	private BufferedReader br;
	private DataOutputStream dos;
	private DataInputStream dis;
	private String[] listData;
	//private String fileToGetName;
	
	
	public ClientPane(Stage stage) {
		// TODO Auto-generated constructor stub
		setUPGUI();
		
		btnConnect.setOnAction((e)->
		{
			try {
				
				socket = new Socket("localhost",9876);
				os = socket.getOutputStream();
				is = socket.getInputStream();
				br = new BufferedReader(new InputStreamReader(is));
				pw = new PrintWriter(os,true);
				dis = new DataInputStream(is);
				dos = new DataOutputStream(os);

				 
			} catch(UnknownHostException ex)
			{
				System.err.println("Could not find host");
			}
			catch (IOException ex) {
				// TODO Auto-generated catch block
			System.err.println("I can not beleive it"); 
			ex.printStackTrace();
			}
		});
		
		btnPULL.setOnAction((e)->
		{
			sendCommand(pw,"PULL");
			String response = " ";
			
			response = ReadResponse(br);
			System.out.println(response);
			
			listData = response.split("#");
			
			for(int i =0; i<listData.length;i++)
			{
				listArea.appendText(listData[i]+"\n");
			}
			
		});
		
		btnDOWNLOAD.setOnAction((e) -> {
		    String idToRetrieveText = txtIDToRetrieve.getText();
		    if (!idToRetrieveText.isEmpty()) {
		        sendCommand(pw, "DOWNLOAD " + idToRetrieveText); // Note the space after DOWNLOAD
		        String response = "";

		        try {
		            response = ReadResponse(br);
		            int fileSize = Integer.parseInt(response);
		            responseArea.appendText("File Size Received: " + response + "\n");

		            String fileName = ""; // To store the retrieved file's name
		            for (String s : listData) {
		                StringTokenizer st = new StringTokenizer(s);
		                String id = st.nextToken();
		                String name = st.nextToken();
		                if (id.equals(idToRetrieveText)) {
		                    fileName = name;
		                    break; // No need to continue the loop once the file name is found
		                }
		            }

		            File fileDownload = new File("data/client/" + fileName);
		            FileOutputStream fos = new FileOutputStream(fileDownload);
		            byte[] buffer = new byte[2048];
		            int n;
		            int totalBytes = 0;
		            while (totalBytes < fileSize && (n = dis.read(buffer)) > 0) {
		                fos.write(buffer, 0, n);
		                fos.flush();
		                totalBytes += n;
		            }
		            fos.close();
		            System.out.println("File Saved on client side: " + fileName);

		            // Optionally, display the downloaded image in the GUI if needed.
		            // Update your ImageView using the code you've shown before.

		        } catch (IOException ex) {
		            System.err.println("Error while handling file download: " + ex.getMessage());
		        }
		    }
		});

		
		btnUPLOAD.setOnAction((e) -> {
		    FileChooser fileChooser = new FileChooser();
		    File selectedFile = fileChooser.showOpenDialog(stage);
		    String fileName = selectedFile.getName();
		    int FileID = listData.length + 1;
		    sendCommand(pw, "UPLOAD", String.valueOf(FileID), fileName, String.valueOf(selectedFile.length()));
		    System.out.println("Upload command sent from client");

		    FileInputStream fis;

		    try {
		        fis = new FileInputStream(selectedFile);
		        byte[] buffer = new byte[2048];
		        int n = 0;
		        while ((n = fis.read(buffer)) > 0) {
		            dos.write(buffer, 0, n);
		            dos.flush();
		        }
		        fis.close();
		        System.out.println("File sent for upload");
		        String response = br.readLine();
		        responseArea.appendText("Status of uploaded file: " + response);

		    } catch (FileNotFoundException ex) {
		        System.err.println("File not found: " + ex.getMessage());
		    } catch (IOException ex) {
		        System.err.println("IOException: " + ex.getMessage());
		    }
		});

		

	}
	
	
	
	
	private String ReadResponse(BufferedReader br) {
		// TODO Auto-generated method stub
		String response = "";
		try {
			response = br.readLine();
		} catch (IOException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		return response;
	}




	private void sendCommand(PrintWriter pw, String... args) {
	    StringBuilder command = new StringBuilder();
	    for (String arg : args) {
	        command.append(arg).append(" ");
	    }
	    pw.println(command.toString().trim());
	}




	public void setUPGUI() {
	    setVgap(10);
	    setHgap(10);
	    setAlignment(Pos.CENTER);

	    // Create labels to explain each button's functionality
	    Label lblInstructions = new Label("1. Connect to Server");
	    Label lblIMGLST = new Label("2. Get Image List");
	    Label lblGETIMG = new Label("3. Download Image by ID");
	    Label lblPOSTIMG = new Label("4. Upload Image to Server");


	    btnConnect = new Button("Connect");
	    add(lblInstructions, 0, 0);
	    add(btnConnect, 1, 0);

	    btnPULL = new Button("Get Image List");
	    add(lblIMGLST, 0, 1);
	    add(btnPULL, 1, 1);

	    btnDOWNLOAD = new Button("Download Image");
	    add(lblGETIMG, 0, 2);
	    add(btnDOWNLOAD, 1, 2);

	    btnUPLOAD = new Button("Upload Image");
	    add(lblPOSTIMG, 0, 3);
	    add(btnUPLOAD, 1, 3);


	    listArea = new TextArea();
	    listArea.setPrefHeight(100);
	    add(listArea, 0, 5, 2, 1);

	    txtIDToRetrieve = new TextField();
	    txtIDToRetrieve.setPromptText("Enter Image ID");
	    add(txtIDToRetrieve, 0, 6, 2, 1);

	    responseArea = new TextArea();
	    responseArea.setPrefHeight(150);
	    add(responseArea, 0, 7, 2, 1);
	}

}
