/**
 * 
 */
package acsse.csc2b;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

/**
 * @author nyash
 *
 */


public class Server implements Runnable {
	
	//declaration of variables
	private ServerSocket serverSocket = null;
	private Socket clientConnection = null;
	private PrintWriter pw = null;
	private BufferedReader br = null;
	
	private int port = 8888;
    private boolean running = true;
    private int requestCount;
    private Random random = null;
	
    
    @Override
	public void run() {
		// TODO Auto-generated method stub
		try {
        	//instantiation of a ServerSocket
        	serverSocket = new ServerSocket(port);
            System.out.println("Server is running on port " + port);
            //a socket accepts the server socket and prints "Ready..."
            clientConnection = serverSocket.accept();
            System.out.println("Ready for incoming connections. . .  " );
            
            //instantiating PrintWriter and BufferedReader
            pw = new PrintWriter(clientConnection.getOutputStream(), true); //enabled auto flush
            br = new BufferedReader(new InputStreamReader(
            		                    clientConnection.getInputStream()));
            //prints the foll msg
            pw.println("HELLO - you may make 4 requests and I'll try to detect your language");
            // a for loop to count the number of requests and running
            for (requestCount= 0; running && requestCount < 4; requestCount++) {
                pw.println("REQUEST or DONE");
                String msgRequest = br.readLine();
                 //tries to match the word and exits if correct
                if (msgRequest.equals("DONE")) {
                    pw.println("0# GOOD BYE - " + requestCount + " queries answered");
                    //always good practice to close 
                    pw.close();
                    br.close();
                    running = false; //program should terminate
                } else {
                	//matches the entered words by user
                    String response = checkReq(msgRequest);
                    pw.println("# " + response);
                }
            }         
            System.out.println("Client disconnected");
           //catching the IOException
        } catch (IOException ex) {
            System.err.println("Failed");;
        }
            //finally block since it isn't in ARM
	        finally
	        { 
        	try {        
	        		if(clientConnection != null)
			        {
	        			//Socket is successfully closed
			             clientConnection.close();
			        }
                } catch (IOException ex)
				        	{      
				        	System.err.println("Could not close");       	
				            }
	          }
		
	}

    //a helper function to match requests
    private String checkReq(String request) {
    	 //instantiating a random generator function
         random = new Random();
         int num = random.nextInt(3);
        //users enters words and they're checked to see if they match any of these
        if (request.contains("ngiyabonga") || request.contains("mina")) 
        {
        	//program returns this
            return "I detect some Zulu here.";
        } 
        else if (request.startsWith("Is"))
        {
        	//Is can be an Anglais, English or even Afrikaans, program selects randomly
            
            if (num == 0) {
                return "Anglais?";
            } 
	            else if (num == 1) {
	                return "English?";
            }
	            else {
	                return "Maybe Afrikaans?";
            }
        }
        //Sotho words are also tested
        else if (request.contains("Dumela"))
        {
        	//a return
            return "I greet you in Sotho!";
        }
        else {
            //same for the below code
            if (num == 0) {
                return "Howzit";
            } 
	            else if (num == 1) {
	                return "I'm still learning";
            }
	            else {
	                return "No idea";
            }
        }
    }

	

}


