import acsse.csc2b.Server;

/**
 * 
 */

/**
 * @author nyash
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Server newServer = new Server();
		Thread serverThread = new Thread(newServer);
        serverThread.start();
	}

}
